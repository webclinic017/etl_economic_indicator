
# Change Log
All notable changes to this project will be documented in this file.
 
 ## v1.0.1 - 2021-09-06

  fix bug - missing Oct from the list of periods
## v1.0.0 - 2021-09-06
 
  Intial release

