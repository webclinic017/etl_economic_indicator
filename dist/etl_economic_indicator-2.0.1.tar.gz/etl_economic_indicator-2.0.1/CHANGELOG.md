
# Change Log
All notable changes to this project will be documented in this file.
## v2.0.1 - 11/26/2021
  1. add error handler
## v2.0.0 - 11/26/2021
  1 Update python dependencies
## v1.0.1 - 11/22/2021
  1. Bug fix - Added while loop for failed clicks in Apply Button id
  2. Bug fix - Added sql connection for windows for getting the latest date available

## v1.0.1 - 11/22/2021
  1. Add feature - run in ubuntu

## v1.0.1 - 2021-09-06

  fix bug - missing Oct from the list of periods
## v1.0.0 - 2021-09-06
 
  Intial release

